import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Ansinda Communication Indonesia System",
  description: "Develop by Ghiffari",
};