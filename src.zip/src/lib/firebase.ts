import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: 'AIzaSyBVSdXxEmq_G95JRMelxWa8aStac2rjBf0',
  authDomain: 'aci-system.firebaseapp.com',
  projectId: 'aci-system',
  storageBucket: 'aci-system.firebasestorage.app',
  messagingSenderId: '539761279016',
  appId: '1:539761279016:web:a59dacd4456077fb27f51d',
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);